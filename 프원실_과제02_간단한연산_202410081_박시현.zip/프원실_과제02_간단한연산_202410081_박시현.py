#섭씨를 화씨로 변환하는 프로그램을 작성하라.
##섭씨 20도는 화씨로 얼마인가?
temp_c=30
temp_f=(9/5)*temp_c+32
print('{}C => {}F'.format(temp_c,temp_f))
##섭씨 0도는 화씨로 얼마인가?
temp_c=0
temp_f=(9/5)*temp_c+32
print('{}C => {}F'.format(temp_c,temp_f))

#키와 몸무게가 임의로 주어졌을 때 BMI를 구하시오.
a=float(input('weight (kg): '))
b=float(input('height (m) : '))
BMI=a/(b**2)
print('BMI : ', BMI)

#반지름이 4라고 주어졌을 떄, 원의 면적을 구하시오.
r=4
pi=3.14
S=pi*(r**2)
print('원의 넓이 : ', S)

#밑변이 5, 윗변이 3, 높이가 4인 사다리꼴의 면적을 구하시오.
a=5
b=3
h=4
S=(a+b)*4*(1/2)
print('사다리꼴의 넓이 : ',S)

#할인행사를 하고 있다. 물건값이 2000원일때, 15% 할인한 가격을 구하시오.
original_price=2000
discount=0.15
price=original_price*(1-discount)
print('할인된 가격 : ',price)